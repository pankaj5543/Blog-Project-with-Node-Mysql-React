import React from 'react'

const Login = () => {
  return (
    <div className="auth">
      
        <form>
              <h1>Login</h1>
            <input type="text" placeholder="username" />
            <input type="password" placeholder="password" />
            <button>Submit</button>
        </form>
    </div>
  )
}

export default Login